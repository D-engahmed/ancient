# Wiring v2: persona + scoping guard + token budgeting

This supersedes the single `tool-governor.ts` file from before — delete that
one, everything it did now lives inside `governor/exploration-budget.ts`,
composed alongside the new pieces.

## 1. Where each file goes
```
packages/server/src/lib/
  token-budget.ts              (new — shared utility)
  project-map.ts                (replace the old one)
  governor/
    index.ts                    (new)
    exploration-budget.ts       (new — replaces tool-governor.ts)
    scoping-guard.ts            (new)
    rules/
      persona.md                (new)
      scoping-rules.md          (new — your rules, verbatim)
```

## 2. Update `packages/server/src/tools/index.ts`

```ts
import { createGovernor } from "../lib/governor";

export function buildTools() {
  const governor = createGovernor({ explorationBudget: 8, readTokenBudget: 1500 });

  return {
    readFile: tool({
      description: "Read the contents of a file",
      parameters: z.object({ path: z.string() }),
      execute: governor.guardRead(async ({ path }) => {
        // <-- unchanged existing logic
      }),
    }),

    listDirectory: tool({
      description: "List the contents of a directory",
      parameters: z.object({ path: z.string() }),
      execute: governor.guardList(async ({ path }) => {
        // <-- unchanged existing logic
      }),
    }),

    writeFile: tool({
      description: "Write or overwrite a file",
      parameters: z.object({ path: z.string(), content: z.string() }),
      execute: governor.guardWrite(async ({ path, content }) => {
        // <-- unchanged existing logic
      }),
    }),

    // other tools unchanged
  };
}
```

## 3. Update `packages/server/src/routes/chat.ts`

Two additions to what was already there — the project map import changes
slightly (new options shape), and you now also append the governor's
persona/scoping text to your system prompt:

```ts
import { getProjectMap, formatProjectMapForContext } from "../lib/project-map";
import { createGovernor } from "../lib/governor";

// inside your chat handler, before streamText:
const governor = createGovernor(); // same instance used to build tools this turn
const projectMap = await getProjectMap(process.cwd());

const systemPrompt = [
  yourExistingSystemPromptText,       // whatever system-prompt.ts already exports
  governor.systemPromptAddendum,      // persona + scoping rules
  formatProjectMapForContext(projectMap),
].join("\n\n---\n\n");
```

(Build `governor` once per turn and pass the same instance into both
`buildTools()` and the system prompt assembly, so the scoping guard's
"touched paths" tracking and the exploration budget are shared across the
whole turn — not reset independently in two different places.)

## 4. What changed vs. the first pass

| | v1 | v2 |
|---|---|---|
| Duplicate reads | blocked | blocked |
| Read-only call budget | blocked at 8 | blocked at 8 |
| Large file reads | full content returned | capped at ~1500 tokens, with a note on how to read more |
| Project map | fixed depth-3 tree | adaptive depth, backs off until it fits a token budget |
| Cross-package/cross-concern writes | not checked | blocked per your scoping rules |
| "Act like an engineer" | implicit in system-prompt.ts wording | explicit persona.md, composed with the code-enforced pieces |

## 5. Test it
Same test as before — the README-update prompt — plus a new one to check
the scoping guard: ask it to do something that should legitimately span
two unrelated route handlers (e.g. "add logging to both chat.ts and
sessions.ts") and confirm the second `Write File` gets blocked with the
scope-mismatch message instead of silently going through.

## 6. On output tokens specifically
Code can cap what comes *back* from a tool (input side) reliably — that's
what `truncateFileContent` and the project-map budget do. It can't force
the model's own generated output to be short the same way, since that's
generation, not retrieval. Two things do the most for output tokens in
practice:
- The persona's "prefer a diff/patch over re-pasting a whole file" line.
- If your `writeFile` tool currently requires the model to send back the
  *entire* file content to make a small edit, that's the single biggest
  output-token cost in your loop — bigger than anything else here. Worth
  adding a find-and-replace style `editFile` tool (old string → new string,
  like a patch) as the default for edits to existing files, reserving full
  `writeFile` for genuinely new files. Say the word and I'll build that one
  too — it's a natural next piece.
